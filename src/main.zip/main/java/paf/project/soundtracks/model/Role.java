package paf.project.soundtracks.model;

public enum Role {
    USER,
    REVIEWER,
    MODERATOR,
    ORGANIZER,
    ARTIST,
    STAFF,
    SECURITY,
    GASTRONOMY
}