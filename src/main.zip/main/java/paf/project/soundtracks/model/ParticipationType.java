package paf.project.soundtracks.model;

public enum ParticipationType {
    ATTENDEE,
    PERFORMER,
    STAFF,
    SECURITY,
    GASTRONOMY,
    ORGANIZER
}
