package paf.project.soundtracks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoundtracksApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoundtracksApplication.class, args);
	}

}
